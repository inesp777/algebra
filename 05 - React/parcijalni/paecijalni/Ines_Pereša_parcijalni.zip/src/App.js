import React from 'react';
import Forma from './Components/Forma'


function App() {
  return (
    <div>
<h1>Heloo</h1>
<Forma/>
    </div>
  );
}

export default App;
