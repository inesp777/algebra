export default function Details(props) {
    return (
        <div>
            <h1>{props.name}</h1>
            <p>Bio: {props.bio}</p>
            <p>LOCATION: {props.location}</p>
            <p>Repositories:</p>
            {props.repo.map(item =>
                <div key={item.id}>
                    <p>{item.name}</p>
                </div>)}

        </div>

    )

}